# BookNest research record
Review date: 17 October 2026. Method: public-page text retrieval, not an interactive usability audit. No screenshots or performance estimates are claimed.

## CW1 - Crossword
Observation: Homepage text exposes a title/author/ISBN search field and fiction subgenres.
Evidence locator: Homepage search field and Fiction menu
Source: https://www.crossword.in/
Interpretation (hypothesis): Test a mood-first checklist alongside genre discovery.
Limit: Observation only; search operation and usability not tested.

## CW2 - Crossword
Observation: Homepage text contains bestseller and coming-soon sections.
Evidence locator: Best Sellers and Coming Soon headings
Source: https://www.crossword.in/
Interpretation (hypothesis): Use separate discovery and upcoming-read content pillars.
Limit: Visible labels only; sales and popularity not independently verified.

## SP1 - SapnaOnline
Observation: Homepage text exposes title/author/ISBN search and Kannada navigation.
Evidence locator: Search field and Kannada navigation
Source: https://www.sapnaonline.com/
Interpretation (hypothesis): Ask readers their preferred language before narrowing the content scope.
Limit: Search operation and audience demand not tested.

## SP2 - SapnaOnline
Observation: Homepage text groups books into fiction, nonfiction and new-arrival sections.
Evidence locator: Top 20 Fiction, Top 20 Non Fiction, New Arrivals headings
Source: https://www.sapnaonline.com/
Interpretation (hypothesis): Keep evergreen selection guides separate from time-sensitive discovery posts.
Limit: Section labels only; ranking methodology not assessed.

## AM0 - Amazon India Books
Observation: Books bestseller page returned a retrieval error during this review.
Evidence locator: Retrieval attempt on 17 October 2026
Source: https://www.amazon.in/gp/bestsellers/books
Interpretation (hypothesis): Keep Amazon comparison unassessed and revisit manually.
Limit: No conclusion about website availability or features.
